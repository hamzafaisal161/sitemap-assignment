# frozen_string_literal: true

require_relative 'assignment'
require 'nokogiri'
require 'byebug'
require 'open-uri'
if ARGV.length != 1
  puts 'Invalid command line arguments.'
else
  domain = ARGV[0]
end

puts domain
object = Assignment::Dfs.new(domain)
object.dfs
builder = Nokogiri::XML::Builder.new do |xml|
  xml.urlset('xmlns' => domain) do
    object.visited_links.each do |o|
      xml.url do
        xml.loc(o)
      end
    end
  end
end
puts builder.to_xml
