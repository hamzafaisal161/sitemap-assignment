# frozen_string_literal: true

module Assignment
  class Dfs
    attr_accessor :visited_links

    @unvisited_links = []
    @visited_links = []
    @domain = ''
    def initialize(domain)
      @domain = domain
      @unvisited_links = []
      @visited_links = []
      @unvisited_links.append(@domain)
    end

    def get_links(url)
      unless url.nil?
        doc = Nokogiri::HTML(open(url))
        doc.css('a').map do |link|
          if (href = link.attr('href')) && !href.empty?
            URI.join(url, href).to_s
          end
        end.compact.uniq
      end
    end

    def dfs
      while @unvisited_links.length.positive?
        url = @unvisited_links.pop
        @visited_links.append(url) unless @visited_links.include?(url)
        links = get_links(url)
        next if links.nil?

        links.each do |link|
          next unless link.include?(@domain) || link[0] == '/'

          @unvisited_links.append(link) if !@unvisited_links.include?(link) && !@visited_links.include?(link)
        end
      end
    end
  end
end
